The best code is the code that doesn't need to be written.
# The Standard — Technical Specification

## Component Inventory

### shadcn/ui Components (Built-in)
- `button` — CTAs, form submit
- `card` — Package cards, Continuity cards
- `dialog` — Form modal
- `input` — Form fields
- `textarea` — Current Challenge field
- `select` — Dropdowns (Package, Budget, Timeline)
- `accordion` — Terms & Guarantees
- `label` — Form labels
- `separator` — Dividers

### Custom Components to Build

| Component | Purpose | Location |
|-----------|---------|----------|
| `Hero` | Section 1: The Silence | `src/sections/Hero.tsx` |
| `FoundingPrinciple` | Section 2: Philosophy | `src/sections/FoundingPrinciple.tsx` |
| `FourPillars` | Section 3: Services | `src/sections/FourPillars.tsx` |
| `Packages` | Section 4: Pricing tiers | `src/sections/Packages.tsx` |
| `Continuity` | Section 5: Maintenance | `src/sections/Continuity.tsx` |
| `NextSteps` | Section 6: Process | `src/sections/NextSteps.tsx` |
| `ContactModal` | Form modal | `src/components/ContactModal.tsx` |
| `CalendlyModal` | Calendly integration | `src/components/CalendlyModal.tsx` |
| `ScrollReveal` | Animation wrapper | `src/components/ScrollReveal.tsx` |
| `PillarPanel` | Animated pillar card | `src/components/PillarPanel.tsx` |
| `PackageCard` | Pricing card with accordion | `src/components/PackageCard.tsx` |
| `EntityCard` | Three Entities card | `src/components/EntityCard.tsx` |
| `StepNumber` | Large outlined number | `src/components/StepNumber.tsx` |

### Custom Hooks

| Hook | Purpose | Location |
|------|---------|----------|
| `useScrollAnimation` | GSAP ScrollTrigger setup | `src/hooks/useScrollAnimation.ts` |
| `useReducedMotion` | Respect prefers-reduced-motion | `src/hooks/useReducedMotion.ts` |

---

## Animation Implementation Table

| Animation | Library | Implementation Approach | Complexity |
|-----------|---------|------------------------|------------|
| **Phase 1-3 Scroll Reveal** | GSAP ScrollTrigger | Custom ScrollReveal component with timeline | High |
| **Hero Tagline Fade** | GSAP | Simple fromTo with delay | Low |
| **Hero Title Entrance** | GSAP | fromTo translateY + opacity after tagline | Low |
| **Diamond Pulse** | CSS Keyframes | Infinite opacity animation | Low |
| **Section Headers** | GSAP ScrollTrigger | Phase 1: translateY(80px), opacity 0 | Medium |
| **Body Text Stagger** | GSAP ScrollTrigger | Staggered children with 100ms delay | Medium |
| **Entity Cards** | GSAP ScrollTrigger | Horizontal scroll mobile, stack desktop | Medium |
| **Four Pillars Convergence** | GSAP ScrollTrigger | Each from different direction | High |
| **Pillar Hover Expand** | CSS + React State | Flex-grow transition 600ms | Medium |
| **Package Cards Scale** | GSAP ScrollTrigger | scale(0.95) to scale(1) | Medium |
| **Card Shadow Hover** | CSS | box-shadow transition on hover | Low |
| **Accordion Expand** | Framer Motion | AnimatePresence height animation | Medium |
| **Chevron Rotation** | CSS | transform rotate 180deg | Low |
| **Step Numbers Outline** | GSAP ScrollTrigger | Stroke animation or fade | Medium |
| **Modal Backdrop** | Framer Motion | opacity + scale animation | Medium |
| **Form Success Checkmark** | CSS/Framer | Scale + opacity animation | Low |
| **Button Hover Scale** | CSS | transform scale(1.02) | Low |
| **CTA Border Glow** | CSS | box-shadow with gold accent | Low |

---

## Animation Library Choices

### Primary: GSAP + ScrollTrigger
**Rationale:**
- Precise control over scroll-linked animations
- Three-phase structure requires timeline control
- Performance optimized with transform3d
- Industry standard for complex scroll animations

**Usage:**
- All section entrance/exit animations
- Staggered reveals
- Scroll-triggered timelines

### Secondary: Framer Motion
**Rationale:**
- React-native integration
- Excellent for mount/unmount animations
- AnimatePresence for modal transitions

**Usage:**
- Modal animations
- Accordion content
- Success state transitions

### CSS Animations
**Rationale:**
- Lightweight for simple loops
- No JS overhead for continuous animations

**Usage:**
- Diamond pulse
- Button hovers
- Chevron rotation

---

## Project File Structure

```
/mnt/okcomputer/output/app/
├── public/
│   └── (no images - typography only)
├── src/
│   ├── sections/
│   │   ├── Hero.tsx
│   │   ├── FoundingPrinciple.tsx
│   │   ├── FourPillars.tsx
│   │   ├── Packages.tsx
│   │   ├── Continuity.tsx
│   │   └── NextSteps.tsx
│   ├── components/
│   │   ├── ScrollReveal.tsx
│   │   ├── ContactModal.tsx
│   │   ├── CalendlyModal.tsx
│   │   ├── PillarPanel.tsx
│   │   ├── PackageCard.tsx
│   │   ├── EntityCard.tsx
│   │   └── StepNumber.tsx
│   ├── hooks/
│   │   ├── useScrollAnimation.ts
│   │   └── useReducedMotion.ts
│   ├── lib/
│   │   └── utils.ts
│   ├── styles/
│   │   └── animations.css
│   ├── App.tsx
│   ├── index.css
│   └── main.tsx
├── components/ui/          (shadcn components)
├── index.html
├── tailwind.config.js
├── vite.config.ts
└── package.json
```

---

## Dependencies

### Already Installed
- React 18+
- TypeScript
- Vite
- Tailwind CSS 3.4.19
- shadcn/ui components
- Radix UI primitives

### Additional Required
- `gsap` — Animation engine
- `@gsap/react` — React integration
- `framer-motion` — Modal/accordion animations
- `react-calendly` — Calendly integration

---

## Technical Implementation Notes

### ScrollReveal Component Pattern
```tsx
// Wrapper component for three-phase animations
<ScrollReveal 
  phase1={{ y: 80, opacity: 0, rotateX: 8 }}
  phase2={{ y: 0, opacity: 1, rotateX: 0 }}
  phase3={{ y: -60, opacity: 0.3 }}
  duration={0.8}
  stagger={0.1}
>
  {children}
</ScrollReveal>
```

### GSAP ScrollTrigger Setup
```tsx
// Per-section timeline
gsap.timeline({
  scrollTrigger: {
    trigger: sectionRef.current,
    start: "top 80%",
    end: "bottom 20%",
    toggleActions: "play none none reverse"
  }
})
```

### Reduced Motion Support
```tsx
const prefersReducedMotion = useReducedMotion();
// Skip Phase 1/3, keep Phase 2 static
```

### Performance Optimizations
- Use `will-change: transform, opacity` on animated elements
- GPU-accelerated transforms only
- Lazy load Calendly widget
- Respect prefers-reduced-motion

---

## Responsive Breakpoints

| Breakpoint | Width | Layout Changes |
|------------|-------|----------------|
| Mobile | < 640px | Single column, horizontal scroll for cards |
| Tablet | 640-1024px | 2-column grids |
| Desktop | > 1024px | Full layouts, four columns |

---

## Color CSS Variables

```css
:root {
  --bg-primary: #0A0A0A;
  --bg-secondary: #050505;
  --text-primary: #F5F5F0;
  --text-secondary: #6B6B6B;
  --accent: #C4A77D;
  --accent-hover: #D4B78D;
}
```
