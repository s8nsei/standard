import { useState, useEffect } from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Hero } from '@/sections/Hero';
import { FoundingPrinciple } from '@/sections/FoundingPrinciple';
import { FourPillars } from '@/sections/FourPillars';
import { Packages, type Package } from '@/sections/Packages';
import { Continuity } from '@/sections/Continuity';
import { NextSteps } from '@/sections/NextSteps';
import { ContactModal } from '@/components/ContactModal';
import { CalendlyModal } from '@/components/CalendlyModal';
import { CookieConsent, withdrawConsent } from '@/components/CookieConsent';
import { PrivacyPolicy } from '@/pages/PrivacyPolicy';
import { TermsOfService } from '@/pages/TermsOfService';
import './App.css';

// Register GSAP plugins
gsap.registerPlugin(ScrollTrigger);

function HomePage() {
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [isCalendlyModalOpen, setIsCalendlyModalOpen] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState<string | undefined>();

  // Refresh ScrollTrigger on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      ScrollTrigger.refresh();
    }, 100);

    return () => {
      clearTimeout(timer);
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  const handlePackageSelect = (pkg: Package) => {
    setSelectedPackage(pkg.id);
    setIsContactModalOpen(true);
  };

  const handleRequestPlan = () => {
    setSelectedPackage(undefined);
    setIsContactModalOpen(true);
  };

  const handleBookCall = () => {
    setIsCalendlyModalOpen(true);
  };

  const handleContactModalClose = () => {
    setIsContactModalOpen(false);
    setSelectedPackage(undefined);
  };

  const handleCalendlyModalClose = () => {
    setIsCalendlyModalOpen(false);
  };

  return (
    <>
      <main className="bg-standard-bg min-h-screen">
        {/* Hero Section */}
        <Hero />

        {/* Founding Principle Section */}
        <FoundingPrinciple />

        {/* Four Pillars Section */}
        <FourPillars />

        {/* Packages Section */}
        <Packages onPackageSelect={handlePackageSelect} />

        {/* Continuity Section */}
        <Continuity />

        {/* Next Steps Section */}
        <NextSteps 
          onRequestPlan={handleRequestPlan} 
          onBookCall={handleBookCall} 
        />

        {/* Footer */}
        <footer className="py-12 px-6 md:px-12 lg:px-20 bg-standard-bg-dark border-t border-standard-muted/10">
          <div className="max-w-6xl mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-center gap-6">
              <div className="text-center md:text-left">
                <h4 className="font-space font-bold text-standard-text uppercase tracking-widest text-lg">
                  THE STANDARD
                </h4>
                <p className="font-inter text-standard-muted text-sm mt-2">
                  Los Angeles, CA
                </p>
              </div>
              <div className="flex flex-col md:flex-row items-center gap-4 md:gap-8">
                <a 
                  href="mailto:hello@thestandard.digital" 
                  className="font-inter text-standard-text/70 text-sm hover:text-standard-gold transition-colors"
                >
                  hello@thestandard.digital
                </a>
              </div>
            </div>
            
            {/* Legal Links */}
            <div className="mt-8 pt-6 border-t border-standard-muted/10">
              <div className="flex flex-wrap justify-center gap-6 mb-4">
                <Link 
                  to="/privacy" 
                  className="font-inter text-standard-text/60 text-xs hover:text-standard-gold transition-colors"
                >
                  Privacy Policy
                </Link>
                <Link 
                  to="/terms" 
                  className="font-inter text-standard-text/60 text-xs hover:text-standard-gold transition-colors"
                >
                  Terms of Service
                </Link>
                <button 
                  onClick={() => withdrawConsent()}
                  className="font-inter text-standard-text/60 text-xs hover:text-standard-gold transition-colors"
                >
                  Cookie Settings
                </button>
                <a 
                  href="#" 
                  className="font-inter text-standard-text/60 text-xs hover:text-standard-gold transition-colors"
                >
                  Accessibility
                </a>
              </div>
              <p className="font-inter text-standard-muted text-xs text-center mb-2">
                &copy; 2026 The Standard. Los Angeles, California. All rights reserved.
              </p>
              <p className="font-inter text-standard-gold/60 text-xs text-center italic">
                "What is extraordinary elsewhere is ordinary here."
              </p>
            </div>
          </div>
        </footer>

        {/* Modals */}
        <ContactModal
          isOpen={isContactModalOpen}
          onClose={handleContactModalClose}
          preSelectedPackage={selectedPackage}
        />

        <CalendlyModal
          isOpen={isCalendlyModalOpen}
          onClose={handleCalendlyModalClose}
        />
      </main>

      {/* Cookie Consent Banner */}
      <CookieConsent />
    </>
  );
}

function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/privacy" element={<PrivacyPolicy />} />
      <Route path="/terms" element={<TermsOfService />} />
    </Routes>
  );
}

export default App;
