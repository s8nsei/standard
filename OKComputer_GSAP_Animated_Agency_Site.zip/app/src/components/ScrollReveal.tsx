import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useReducedMotion } from '@/hooks/useReducedMotion';

gsap.registerPlugin(ScrollTrigger);

interface ScrollRevealProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  duration?: number;
  y?: number;
  rotateX?: number;
  stagger?: number;
  start?: string;
  end?: string;
  scrub?: boolean | number;
  markers?: boolean;
  once?: boolean;
}

export function ScrollReveal({
  children,
  className = '',
  delay = 0,
  duration = 0.8,
  y = 80,
  rotateX = 0,
  stagger = 0.1,
  start = 'top 80%',
  end = 'bottom 20%',
  scrub = false,
  markers = false,
  once = true,
}: ScrollRevealProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;

    const container = containerRef.current;
    if (!container) return;

    const childrenElements = container.children;
    if (childrenElements.length === 0) return;

    // Set initial state
    gsap.set(childrenElements, {
      y,
      opacity: 0,
      rotateX,
      transformPerspective: rotateX ? 1000 : undefined,
    });

    // Create animation timeline
    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: container,
        start,
        end,
        scrub,
        markers,
        toggleActions: once ? 'play none none none' : 'play reverse play reverse',
      },
    });

    tl.to(childrenElements, {
      y: 0,
      opacity: 1,
      rotateX: 0,
      duration,
      delay,
      stagger,
      ease: 'expo.out',
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => {
        if (st.trigger === container) {
          st.kill();
        }
      });
    };
  }, [prefersReducedMotion, delay, duration, y, rotateX, stagger, start, end, scrub, markers, once]);

  // For reduced motion, just render without animation
  if (prefersReducedMotion) {
    return <div className={className}>{children}</div>;
  }

  return (
    <div ref={containerRef} className={`perspective-1000 ${className}`}>
      {children}
    </div>
  );
}

// Simple fade reveal for single elements
interface FadeRevealProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  duration?: number;
  direction?: 'up' | 'down' | 'left' | 'right';
}

export function FadeReveal({
  children,
  className = '',
  delay = 0,
  duration = 0.6,
  direction = 'up',
}: FadeRevealProps) {
  const elementRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;

    const element = elementRef.current;
    if (!element) return;

    const directionMap = {
      up: { y: 60, x: 0 },
      down: { y: -60, x: 0 },
      left: { y: 0, x: 60 },
      right: { y: 0, x: -60 },
    };

    const { x, y } = directionMap[direction];

    gsap.set(element, { y, x, opacity: 0 });

    gsap.to(element, {
      y: 0,
      x: 0,
      opacity: 1,
      duration,
      delay,
      ease: 'expo.out',
      scrollTrigger: {
        trigger: element,
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => {
        if (st.trigger === element) {
          st.kill();
        }
      });
    };
  }, [prefersReducedMotion, delay, duration, direction]);

  if (prefersReducedMotion) {
    return <div className={className}>{children}</div>;
  }

  return (
    <div ref={elementRef} className={className}>
      {children}
    </div>
  );
}
