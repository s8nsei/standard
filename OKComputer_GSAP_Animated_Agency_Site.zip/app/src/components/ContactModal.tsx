import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  preSelectedPackage?: string;
}

interface FormData {
  name: string;
  email: string;
  company: string;
  challenge: string;
  packageInterest: string;
  budgetRange: string;
  timeline: string;
}

const initialFormData: FormData = {
  name: '',
  email: '',
  company: '',
  challenge: '',
  packageInterest: '',
  budgetRange: '',
  timeline: '',
};

export function ContactModal({ isOpen, onClose, preSelectedPackage }: ContactModalProps) {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({});
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (preSelectedPackage) {
      setFormData(prev => ({ ...prev, packageInterest: preSelectedPackage }));
    }
  }, [preSelectedPackage]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen && !isSubmitted) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [isOpen, isSubmitted, onClose]);

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof FormData, string>> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    // Collect submission data with timestamp and IP for audit trail
    const submissionData = {
      ...formData,
      timestamp: new Date().toISOString(),
      userAgent: navigator.userAgent,
      // IP would be captured server-side
    };

    // In production, this would send to your backend API
    // which would then email hello@thestandard.digital
    // Example: await fetch('/api/contact', { method: 'POST', body: JSON.stringify(submissionData) });
    
    // For demo purposes, log to console (remove in production)
    console.log('Form submission:', submissionData);

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 500));

    setIsSubmitted(true);

    // Auto-close after 4 seconds
    setTimeout(() => {
      onClose();
      setIsSubmitted(false);
      setFormData(initialFormData);
    }, 4000);
  };

  const handleChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === modalRef.current && !isSubmitted) {
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          ref={modalRef}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ backgroundColor: 'rgba(0, 0, 0, 0.9)' }}
          onClick={handleBackdropClick}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto bg-standard-bg border border-standard-muted/30"
          >
            {/* Close Button */}
            {!isSubmitted && (
              <button
                onClick={onClose}
                className="absolute top-4 right-4 text-standard-muted hover:text-standard-text transition-colors"
              >
                <X size={24} strokeWidth={1.5} />
              </button>
            )}

            <div className="p-8">
              <AnimatePresence mode="wait">
                {!isSubmitted ? (
                  <motion.div
                    key="form"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <h3 className="font-space font-bold text-standard-text uppercase tracking-widest text-xl mb-2">
                      Request The Architectural Plan
                    </h3>
                    <p className="font-inter text-standard-text/60 text-sm mb-8">
                      Complete the form below. The Architect will review your physics within 24 hours.
                    </p>

                    <form onSubmit={handleSubmit} className="space-y-6">
                      {/* Name */}
                      <div>
                        <Label htmlFor="name" className="text-standard-text/80 text-sm uppercase tracking-wider">
                          Name <span className="text-standard-gold">*</span>
                        </Label>
                        <Input
                          id="name"
                          value={formData.name}
                          onChange={(e) => handleChange('name', e.target.value)}
                          className="mt-2 bg-standard-bg-dark border-standard-muted/30 text-standard-text focus:border-standard-gold focus:ring-standard-gold/20"
                          placeholder="Your name"
                        />
                        {errors.name && (
                          <p className="text-standard-gold text-xs mt-1">{errors.name}</p>
                        )}
                      </div>

                      {/* Email */}
                      <div>
                        <Label htmlFor="email" className="text-standard-text/80 text-sm uppercase tracking-wider">
                          Email <span className="text-standard-gold">*</span>
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => handleChange('email', e.target.value)}
                          className="mt-2 bg-standard-bg-dark border-standard-muted/30 text-standard-text focus:border-standard-gold focus:ring-standard-gold/20"
                          placeholder="your@email.com"
                        />
                        {errors.email && (
                          <p className="text-standard-gold text-xs mt-1">{errors.email}</p>
                        )}
                      </div>

                      {/* Company */}
                      <div>
                        <Label htmlFor="company" className="text-standard-text/80 text-sm uppercase tracking-wider">
                          Company / Project Name
                        </Label>
                        <Input
                          id="company"
                          value={formData.company}
                          onChange={(e) => handleChange('company', e.target.value)}
                          className="mt-2 bg-standard-bg-dark border-standard-muted/30 text-standard-text focus:border-standard-gold focus:ring-standard-gold/20"
                          placeholder="Your company or project"
                        />
                      </div>

                      {/* Current Challenge */}
                      <div>
                        <Label htmlFor="challenge" className="text-standard-text/80 text-sm uppercase tracking-wider">
                          Current Challenge
                        </Label>
                        <Textarea
                          id="challenge"
                          value={formData.challenge}
                          onChange={(e) => handleChange('challenge', e.target.value)}
                          className="mt-2 bg-standard-bg-dark border-standard-muted/30 text-standard-text focus:border-standard-gold focus:ring-standard-gold/20 min-h-[100px]"
                          placeholder="Describe your current physics..."
                        />
                      </div>

                      {/* Package Interest */}
                      <div>
                        <Label className="text-standard-text/80 text-sm uppercase tracking-wider">
                          Package Interest
                        </Label>
                        <Select
                          value={formData.packageInterest}
                          onValueChange={(value) => handleChange('packageInterest', value)}
                        >
                          <SelectTrigger className="mt-2 bg-standard-bg-dark border-standard-muted/30 text-standard-text focus:ring-standard-gold/20">
                            <SelectValue placeholder="Select a package" />
                          </SelectTrigger>
                          <SelectContent className="bg-standard-bg-dark border-standard-muted/30">
                            <SelectItem value="foundation">The Foundation</SelectItem>
                            <SelectItem value="momentum">The Momentum</SelectItem>
                            <SelectItem value="dominance">The Dominance</SelectItem>
                            <SelectItem value="enterprise">The Enterprise</SelectItem>
                            <SelectItem value="unsure">Unsure</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Budget Range */}
                      <div>
                        <Label className="text-standard-text/80 text-sm uppercase tracking-wider">
                          Budget Range
                        </Label>
                        <Select
                          value={formData.budgetRange}
                          onValueChange={(value) => handleChange('budgetRange', value)}
                        >
                          <SelectTrigger className="mt-2 bg-standard-bg-dark border-standard-muted/30 text-standard-text focus:ring-standard-gold/20">
                            <SelectValue placeholder="Select budget range" />
                          </SelectTrigger>
                          <SelectContent className="bg-standard-bg-dark border-standard-muted/30">
                            <SelectItem value="under-5k">Under $5K</SelectItem>
                            <SelectItem value="5k-10k">$5K - $10K</SelectItem>
                            <SelectItem value="10k-25k">$10K - $25K</SelectItem>
                            <SelectItem value="25k-plus">$25K+</SelectItem>
                            <SelectItem value="undisclosed">Undisclosed</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Timeline */}
                      <div>
                        <Label className="text-standard-text/80 text-sm uppercase tracking-wider">
                          Timeline
                        </Label>
                        <Select
                          value={formData.timeline}
                          onValueChange={(value) => handleChange('timeline', value)}
                        >
                          <SelectTrigger className="mt-2 bg-standard-bg-dark border-standard-muted/30 text-standard-text focus:ring-standard-gold/20">
                            <SelectValue placeholder="Select timeline" />
                          </SelectTrigger>
                          <SelectContent className="bg-standard-bg-dark border-standard-muted/30">
                            <SelectItem value="immediate">Immediate</SelectItem>
                            <SelectItem value="30-days">30 days</SelectItem>
                            <SelectItem value="90-days">90 days</SelectItem>
                            <SelectItem value="exploring">Exploring</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {/* Submit Button */}
                      <button
                        type="submit"
                        className="btn-primary w-full mt-8"
                      >
                        Send The Blueprint Request
                      </button>
                    </form>
                  </motion.div>
                ) : (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.4, ease: 'easeOut' }}
                    className="text-center py-12"
                  >
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.2, duration: 0.4, type: 'spring' }}
                      className="w-16 h-16 mx-auto mb-6 rounded-full bg-standard-gold/20 flex items-center justify-center"
                    >
                      <Check className="text-standard-gold" size={32} strokeWidth={2} />
                    </motion.div>
                    <h4 className="font-space font-bold text-standard-text uppercase tracking-widest text-lg mb-4">
                      Your request has been transmitted.
                    </h4>
                    <p className="font-inter text-standard-text/70">
                      The Architect will review your physics within 24 hours.
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
