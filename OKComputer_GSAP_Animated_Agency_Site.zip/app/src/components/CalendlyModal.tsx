import { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { InlineWidget } from 'react-calendly';

interface CalendlyModalProps {
  isOpen: boolean;
  onClose: () => void;
  prefillEmail?: string;
}

export function CalendlyModal({ isOpen, onClose, prefillEmail }: CalendlyModalProps) {
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === modalRef.current) {
      onClose();
    }
  };

  // Calendly prefill configuration
  const prefillConfig = prefillEmail ? { email: prefillEmail } : undefined;

  // Custom Calendly styles for dark theme
  const calendlyStyles = {
    height: '600px',
    minWidth: '320px',
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          ref={modalRef}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ backgroundColor: 'rgba(0, 0, 0, 0.9)' }}
          onClick={handleBackdropClick}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            className="relative w-full max-w-4xl max-h-[90vh] overflow-hidden bg-standard-bg border border-standard-muted/30"
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 z-10 text-standard-muted hover:text-standard-text transition-colors bg-standard-bg/80 p-2"
            >
              <X size={24} strokeWidth={1.5} />
            </button>

            {/* Header */}
            <div className="p-6 border-b border-standard-muted/20">
              <h3 className="font-space font-bold text-standard-text uppercase tracking-widest text-xl">
                Book Discovery Call
              </h3>
              <p className="font-inter text-standard-text/60 text-sm mt-2">
                Select a time that works for you. No pitch. Only pattern recognition.
              </p>
            </div>

            {/* Calendly Widget */}
            <div className="p-4">
              <InlineWidget
                url="https://calendly.com/thestandard-digital/discovery"
                styles={calendlyStyles}
                prefill={prefillConfig}
                pageSettings={{
                  backgroundColor: '0a0a0a',
                  hideEventTypeDetails: false,
                  hideLandingPageDetails: false,
                  primaryColor: 'c9a87c',
                  textColor: 'f5f5f0',
                }}
              />
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
