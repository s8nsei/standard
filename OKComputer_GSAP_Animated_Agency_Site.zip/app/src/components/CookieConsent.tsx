import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { Link } from 'react-router-dom';

interface CookiePreferences {
  essential: boolean;
  analytics: boolean;
  marketing: boolean;
  preferences: boolean;
}

const defaultPreferences: CookiePreferences = {
  essential: true, // Always required
  analytics: false,
  marketing: false,
  preferences: false,
};

const STORAGE_KEY = 'thestandard-cookie-consent';
const EXPIRY_DAYS = 365;

export function CookieConsent() {
  const [isVisible, setIsVisible] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [preferences, setPreferences] = useState<CookiePreferences>(defaultPreferences);

  useEffect(() => {
    // Check if user has already made a choice
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        // Check if consent has expired
        if (parsed.expiry && new Date(parsed.expiry) > new Date()) {
          setPreferences(parsed.preferences);
        } else {
          // Expired, show banner again
          setIsVisible(true);
        }
      } catch {
        setIsVisible(true);
      }
    } else {
      // Check for Do Not Track
      const dnt = navigator.doNotTrack === '1' || (window as any).doNotTrack === '1';
      if (!dnt) {
        // Small delay for better UX
        const timer = setTimeout(() => {
          setIsVisible(true);
        }, 1000);
        return () => clearTimeout(timer);
      }
    }
  }, []);

  const saveConsent = (prefs: CookiePreferences) => {
    const expiry = new Date();
    expiry.setDate(expiry.getDate() + EXPIRY_DAYS);
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      preferences: prefs,
      expiry: expiry.toISOString(),
      timestamp: new Date().toISOString(),
    }));
    
    setPreferences(prefs);
    setIsVisible(false);
    setShowSettings(false);
  };

  const handleAcceptAll = () => {
    const allAccepted: CookiePreferences = {
      essential: true,
      analytics: true,
      marketing: true,
      preferences: true,
    };
    saveConsent(allAccepted);
  };

  const handleSavePreferences = () => {
    saveConsent(preferences);
  };

  const handleDeclineNonEssential = () => {
    saveConsent(defaultPreferences);
  };

  const togglePreference = (key: keyof CookiePreferences) => {
    if (key === 'essential') return; // Cannot toggle essential
    setPreferences(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="fixed bottom-0 left-0 right-0 z-50 p-4 md:p-6"
        >
          <div 
            className="max-w-4xl mx-auto p-6 border"
            style={{ 
              backgroundColor: '#111111', 
              borderColor: 'rgba(201, 168, 124, 0.3)' 
            }}
          >
            {!showSettings ? (
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="flex-1">
                  <p className="font-inter text-[#F5F5F5] text-sm leading-relaxed">
                    We use cookies to analyze site traffic and improve your experience. 
                    By continuing to use this site, you consent to our use of cookies.
                  </p>
                  <div className="flex flex-wrap gap-4 mt-3">
                    <button 
                      onClick={() => setShowSettings(true)}
                      className="font-inter text-[#A0A0A0] text-xs hover:text-[#C9A87C] transition-colors underline"
                    >
                      Cookie Settings
                    </button>
                    <Link to="/privacy" className="font-inter text-[#A0A0A0] text-xs hover:text-[#C9A87C] transition-colors underline">
                      Privacy Policy
                    </Link>
                  </div>
                </div>
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={handleDeclineNonEssential}
                    className="px-4 py-2 font-space text-xs uppercase tracking-wider text-[#A0A0A0] border border-[#333] hover:border-[#C9A87C] hover:text-[#C9A87C] transition-all"
                  >
                    Essential Only
                  </button>
                  <button
                    onClick={handleAcceptAll}
                    className="px-4 py-2 font-space text-xs uppercase tracking-wider bg-[#C9A87C] text-[#0A0A0A] hover:bg-[#0A0A0A] hover:text-[#C9A87C] border border-[#C9A87C] transition-all"
                  >
                    Accept All
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-space font-bold text-[#F5F5F5] uppercase tracking-wider">
                    Cookie Preferences
                  </h3>
                  <button 
                    onClick={() => setShowSettings(false)}
                    className="text-[#A0A0A0] hover:text-[#F5F5F5] transition-colors"
                  >
                    <X size={20} strokeWidth={1.5} />
                  </button>
                </div>

                <div className="space-y-4 mb-6">
                  {/* Essential */}
                  <div className="flex items-center justify-between py-3 border-b border-[#333]">
                    <div>
                      <p className="font-space text-sm text-[#F5F5F5] uppercase tracking-wider">Essential</p>
                      <p className="font-inter text-xs text-[#A0A0A0] mt-1">
                        Required for the website to function properly. Cannot be disabled.
                      </p>
                    </div>
                    <div className="w-12 h-6 bg-[#C9A87C] rounded-full relative cursor-not-allowed">
                      <div className="absolute right-1 top-1 w-4 h-4 bg-[#0A0A0A] rounded-full" />
                    </div>
                  </div>

                  {/* Analytics */}
                  <div 
                    className="flex items-center justify-between py-3 border-b border-[#333] cursor-pointer"
                    onClick={() => togglePreference('analytics')}
                  >
                    <div>
                      <p className="font-space text-sm text-[#F5F5F5] uppercase tracking-wider">Analytics</p>
                      <p className="font-inter text-xs text-[#A0A0A0] mt-1">
                        Helps us understand how visitors interact with our website.
                      </p>
                    </div>
                    <div className={`w-12 h-6 rounded-full relative transition-colors ${preferences.analytics ? 'bg-[#C9A87C]' : 'bg-[#333]'}`}>
                      <div className={`absolute top-1 w-4 h-4 bg-[#0A0A0A] rounded-full transition-all ${preferences.analytics ? 'right-1' : 'left-1'}`} />
                    </div>
                  </div>

                  {/* Marketing */}
                  <div 
                    className="flex items-center justify-between py-3 border-b border-[#333] cursor-pointer"
                    onClick={() => togglePreference('marketing')}
                  >
                    <div>
                      <p className="font-space text-sm text-[#F5F5F5] uppercase tracking-wider">Marketing</p>
                      <p className="font-inter text-xs text-[#A0A0A0] mt-1">
                        Used to deliver relevant advertisements and track their performance.
                      </p>
                    </div>
                    <div className={`w-12 h-6 rounded-full relative transition-colors ${preferences.marketing ? 'bg-[#C9A87C]' : 'bg-[#333]'}`}>
                      <div className={`absolute top-1 w-4 h-4 bg-[#0A0A0A] rounded-full transition-all ${preferences.marketing ? 'right-1' : 'left-1'}`} />
                    </div>
                  </div>

                  {/* Preferences */}
                  <div 
                    className="flex items-center justify-between py-3 border-b border-[#333] cursor-pointer"
                    onClick={() => togglePreference('preferences')}
                  >
                    <div>
                      <p className="font-space text-sm text-[#F5F5F5] uppercase tracking-wider">Preferences</p>
                      <p className="font-inter text-xs text-[#A0A0A0] mt-1">
                        Remember your choices and settings for a better experience.
                      </p>
                    </div>
                    <div className={`w-12 h-6 rounded-full relative transition-colors ${preferences.preferences ? 'bg-[#C9A87C]' : 'bg-[#333]'}`}>
                      <div className={`absolute top-1 w-4 h-4 bg-[#0A0A0A] rounded-full transition-all ${preferences.preferences ? 'right-1' : 'left-1'}`} />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-3">
                  <button
                    onClick={() => setShowSettings(false)}
                    className="px-4 py-2 font-space text-xs uppercase tracking-wider text-[#A0A0A0] hover:text-[#F5F5F5] transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSavePreferences}
                    className="px-4 py-2 font-space text-xs uppercase tracking-wider bg-[#C9A87C] text-[#0A0A0A] hover:bg-[#0A0A0A] hover:text-[#C9A87C] border border-[#C9A87C] transition-all"
                  >
                    Save Preferences
                  </button>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// Export a function to check if analytics are allowed
export function analyticsAllowed(): boolean {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      return parsed.preferences?.analytics === true;
    } catch {
      return false;
    }
  }
  return false;
}

// Export a function to withdraw consent
export function withdrawConsent(): void {
  localStorage.removeItem(STORAGE_KEY);
  window.location.reload();
}
