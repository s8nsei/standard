import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export function TermsOfService() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-standard-bg">
      {/* Header */}
      <header className="py-8 px-6 md:px-12 lg:px-20 border-b border-standard-muted/10">
        <div className="max-w-4xl mx-auto">
          <Link 
            to="/" 
            className="inline-flex items-center gap-2 text-standard-muted hover:text-standard-gold transition-colors"
          >
            <ArrowLeft size={18} strokeWidth={1.5} />
            <span className="font-inter text-sm">Back to Home</span>
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="py-16 px-6 md:px-12 lg:px-20">
        <div className="max-w-4xl mx-auto">
          <h1 className="section-header text-standard-text mb-4" style={{ fontSize: 'clamp(32px, 4vw, 48px)' }}>
            TERMS OF SERVICE
          </h1>
          <p className="text-standard-muted text-sm mb-12">
            Last Updated: April 1, 2026
          </p>

          <div className="space-y-12">
            {/* Acceptance of Terms */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">1. Acceptance of Terms</h2>
              <p className="body-text text-standard-text/80">
                By accessing or using The Standard's website and services, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services. These terms constitute a binding legal agreement between you and The Standard.
              </p>
            </section>

            {/* Description of Services */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">2. Description of Services</h2>
              <p className="body-text text-standard-text/80 mb-4">
                The Standard provides digital marketing services including but not limited to:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Brand identity and strategy</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Social media management</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Paid advertising (Meta, Google, TikTok)</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Email marketing and automation</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Analytics and reporting</span>
                </li>
              </ul>
            </section>

            {/* User Accounts */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">3. User Accounts</h2>
              <p className="body-text text-standard-text/80 mb-4">
                When you create an account or engage our services, you agree to:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Provide accurate and complete information</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Maintain the security of your account credentials</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Notify us immediately of any unauthorized access</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Not engage in prohibited activities including fraud, harassment, or illegal conduct</span>
                </li>
              </ul>
            </section>

            {/* Payment Terms */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">4. Payment Terms</h2>
              <p className="body-text text-standard-text/80 mb-4">
                Payment terms vary by service tier:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>The Foundation:</strong> 50% deposit to initiate, 50% due upon delivery</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>The Momentum:</strong> Quarterly billing in advance</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>The Dominance:</strong> Two payments: $9,000 at commencement, $8,000 at month four</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>The Enterprise:</strong> Quarterly billing in advance, $35,000 per quarter</span>
                </li>
              </ul>
              <p className="body-text text-standard-text/80 mt-4">
                <strong>Refunds:</strong> No pro-rata refunds for mid-cycle cancellations. Clients may exit only upon completion of the committed term. Specific refund terms are outlined in individual service agreements.
              </p>
            </section>

            {/* Intellectual Property */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">5. Intellectual Property</h2>
              <p className="body-text text-standard-text/80 mb-4">
                Upon full payment, you own the final deliverables created specifically for your project. This includes:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Logo designs and brand assets</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Website designs and content</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Marketing materials and creative assets</span>
                </li>
              </ul>
              <p className="body-text text-standard-text/80 mt-4">
                The Standard retains ownership of our proprietary processes, methodologies, templates, and tools. We may use general knowledge and experience gained from working with you in future projects, provided we do not disclose your confidential information.
              </p>
            </section>

            {/* Confidentiality */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">6. Confidentiality</h2>
              <p className="body-text text-standard-text/80">
                Both parties agree to maintain the confidentiality of proprietary information disclosed during the engagement. This includes business strategies, financial information, customer data, and trade secrets. Confidentiality obligations survive termination of the agreement for a period of five years.
              </p>
            </section>

            {/* Limitation of Liability */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">7. Limitation of Liability</h2>
              <p className="body-text text-standard-text/80">
                To the maximum extent permitted by law, The Standard's total liability shall not exceed the total amount paid by you for services in the twelve months preceding the claim. We are not liable for indirect, incidental, special, consequential, or punitive damages. Neither party shall be liable for failure to perform due to causes beyond their reasonable control (force majeure).
              </p>
            </section>

            {/* Indemnification */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">8. Indemnification</h2>
              <p className="body-text text-standard-text/80">
                You agree to indemnify and hold harmless The Standard, its officers, directors, employees, and agents from any claims, damages, losses, or expenses arising from: (a) your use of our services, (b) your violation of these terms, (c) your violation of any third-party rights, or (d) content you provide that infringes intellectual property rights.
              </p>
            </section>

            {/* Governing Law */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">9. Governing Law</h2>
              <p className="body-text text-standard-text/80">
                These Terms of Service are governed by the laws of the State of California, without regard to conflict of law principles. Any legal action shall be brought exclusively in the state or federal courts located in Los Angeles County, California.
              </p>
            </section>

            {/* Dispute Resolution */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">10. Dispute Resolution</h2>
              <p className="body-text text-standard-text/80">
                Any dispute arising from these terms shall first be attempted to be resolved through good faith negotiation. If negotiation fails, the parties agree to non-binding mediation. If mediation is unsuccessful, the dispute shall be resolved through binding arbitration administered by JAMS in accordance with its Comprehensive Arbitration Rules. The arbitration shall take place in Los Angeles, California.
              </p>
            </section>

            {/* Severability */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">11. Severability</h2>
              <p className="body-text text-standard-text/80">
                If any provision of these terms is found to be invalid or unenforceable, that provision shall be severed, and the remaining provisions shall continue in full force and effect.
              </p>
            </section>

            {/* Entire Agreement */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">12. Entire Agreement</h2>
              <p className="body-text text-standard-text/80">
                These Terms of Service, together with any signed service agreements and the Privacy Policy, constitute the entire agreement between you and The Standard regarding the use of our services. These terms supersede all prior agreements, understandings, and communications.
              </p>
            </section>

            {/* Changes to Terms */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">13. Changes to Terms</h2>
              <p className="body-text text-standard-text/80">
                We may modify these Terms of Service at any time. We will provide notice of material changes by posting the updated terms on our website with a revised date. Your continued use of our services after such changes constitutes acceptance of the modified terms.
              </p>
            </section>

            {/* Contact */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">14. Contact Information</h2>
              <p className="body-text text-standard-text/80">
                For questions about these Terms of Service, please contact:<br />
                <strong>hello@thestandard.digital</strong><br />
                +1 (310) 555-0199<br />
                The Standard, Los Angeles, CA
              </p>
            </section>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-8 px-6 md:px-12 lg:px-20 bg-standard-bg-dark border-t border-standard-muted/10">
        <div className="max-w-4xl mx-auto text-center">
          <p className="font-inter text-standard-muted text-xs">
            &copy; 2026 The Standard. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
