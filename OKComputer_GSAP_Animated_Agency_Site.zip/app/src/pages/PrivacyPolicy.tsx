import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export function PrivacyPolicy() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-standard-bg">
      {/* Header */}
      <header className="py-8 px-6 md:px-12 lg:px-20 border-b border-standard-muted/10">
        <div className="max-w-4xl mx-auto">
          <Link 
            to="/" 
            className="inline-flex items-center gap-2 text-standard-muted hover:text-standard-gold transition-colors"
          >
            <ArrowLeft size={18} strokeWidth={1.5} />
            <span className="font-inter text-sm">Back to Home</span>
          </Link>
        </div>
      </header>

      {/* Content */}
      <main className="py-16 px-6 md:px-12 lg:px-20">
        <div className="max-w-4xl mx-auto">
          <h1 className="section-header text-standard-text mb-4" style={{ fontSize: 'clamp(32px, 4vw, 48px)' }}>
            PRIVACY POLICY
          </h1>
          <p className="text-standard-muted text-sm mb-12">
            Effective Date: April 1, 2026
          </p>

          <div className="space-y-12">
            {/* Business Information */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">Business Information</h2>
              <p className="body-text text-standard-text/80">
                The Standard<br />
                Los Angeles, California<br />
                hello@thestandard.digital<br />
                +1 (310) 555-0199
              </p>
            </section>

            {/* Information We Collect */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">Information We Collect</h2>
              <p className="body-text text-standard-text/80 mb-4">
                We collect the following categories of personal information:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Identifiers:</strong> Name, email address, phone number, company name</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Commercial Information:</strong> Services purchased, transaction history</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Internet Activity:</strong> IP address, browser type, pages visited, time spent</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Geolocation Data:</strong> General location derived from IP address</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Professional Information:</strong> Business challenges, project requirements</span>
                </li>
              </ul>
            </section>

            {/* Sources of Information */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">Sources of Information</h2>
              <p className="body-text text-standard-text/80 mb-4">
                We collect personal information from the following sources:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Direct from You:</strong> Information you provide through forms, emails, or calls</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Automatic Collection:</strong> Through cookies and analytics tools</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Third Parties:</strong> Service providers and business partners</span>
                </li>
              </ul>
            </section>

            {/* Use of Information */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">Use of Information</h2>
              <p className="body-text text-standard-text/80 mb-4">
                We use your personal information for the following purposes:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Providing and improving our services</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Communicating with you about projects and inquiries</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Analytics and website performance monitoring</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Marketing communications (with your consent, which you may withdraw at any time)</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Legal compliance and security</span>
                </li>
              </ul>
            </section>

            {/* Sharing Information */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">Sharing Information</h2>
              <p className="body-text text-standard-text/80 mb-4">
                We may share your personal information with:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Service Providers:</strong> Hosting, analytics, and communication platforms</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Legal Compliance:</strong> When required by law or to protect our rights</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Business Transfers:</strong> In connection with a merger, acquisition, or sale</span>
                </li>
              </ul>
              <p className="body-text text-standard-text/80 mt-4">
                <strong>We do not sell your personal information.</strong>
              </p>
            </section>

            {/* Your Rights (CCPA/CPRA) */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">Your Rights (CCPA/CPRA)</h2>
              <p className="body-text text-standard-text/80 mb-4">
                California residents have the following rights regarding their personal information:
              </p>
              <ul className="space-y-3 ml-4">
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Right to Know:</strong> Request disclosure of what personal information we collect, use, and share</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Right to Delete:</strong> Request deletion of your personal information</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Right to Correct:</strong> Request correction of inaccurate personal information</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Right to Opt-Out of Sale/Sharing:</strong> We do not sell personal information</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Right to Limit Use of Sensitive Personal Information:</strong> Request limitations on use of sensitive data</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span><strong>Right to Non-Discrimination:</strong> Exercising your rights will not result in different treatment</span>
                </li>
              </ul>
            </section>

            {/* How to Exercise Rights */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">How to Exercise Your Rights</h2>
              <p className="body-text text-standard-text/80 mb-4">
                To exercise your privacy rights, contact us:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Email: privacy@thestandard.digital</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Phone: +1 (310) 555-0199</span>
                </li>
                <li className="body-text text-standard-text/70 flex items-start gap-2">
                  <span className="text-standard-gold mt-1.5">&#9670;</span>
                  <span>Mail: The Standard, Los Angeles, CA</span>
                </li>
              </ul>
              <p className="body-text text-standard-text/80 mt-4">
                We will respond within 45 days of receiving your request. If additional time is needed, we will notify you and may extend the response period by an additional 45 days.
              </p>
            </section>

            {/* Authorized Agents */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">Authorized Agents</h2>
              <p className="body-text text-standard-text/80">
                You may designate an authorized agent to make requests on your behalf. The agent must provide written authorization from you, and we may require you to verify your identity directly with us.
              </p>
            </section>

            {/* Children's Privacy */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">Children's Privacy</h2>
              <p className="body-text text-standard-text/80">
                Our services are not directed to children under 13 years of age. We do not knowingly collect personal information from children under 13. If you believe we have collected information from a child under 13, please contact us immediately.
              </p>
            </section>

            {/* Security */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">Security</h2>
              <p className="body-text text-standard-text/80">
                We implement appropriate technical and organizational measures to protect your personal information, including TLS 1.3 encryption in transit, AES-256 encryption at rest, and access controls. In the event of a data breach, we will notify affected users and the California Attorney General within 72 hours as required by law.
              </p>
            </section>

            {/* International Transfers */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">International Transfers</h2>
              <p className="body-text text-standard-text/80">
                Your personal information may be processed in the United States. By using our services, you consent to the transfer of your information to the United States.
              </p>
            </section>

            {/* Changes to Policy */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">Changes to This Policy</h2>
              <p className="body-text text-standard-text/80">
                We may update this Privacy Policy from time to time. We will provide 30 days' notice for material changes by posting the updated policy on our website with a revised effective date.
              </p>
            </section>

            {/* Contact */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">Contact Us</h2>
              <p className="body-text text-standard-text/80">
                For privacy-related inquiries, please contact:<br />
                <strong>privacy@thestandard.digital</strong>
              </p>
            </section>

            {/* Shine the Light */}
            <section>
              <h2 className="subheader text-standard-gold mb-4">California "Shine the Light" Law</h2>
              <p className="body-text text-standard-text/80">
                California Civil Code Section 1798.83 permits California residents to request information regarding our disclosure of personal information to third parties for direct marketing purposes. We do not share personal information with third parties for their direct marketing purposes.
              </p>
            </section>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-8 px-6 md:px-12 lg:px-20 bg-standard-bg-dark border-t border-standard-muted/10">
        <div className="max-w-4xl mx-auto text-center">
          <p className="font-inter text-standard-muted text-xs">
            &copy; 2026 The Standard. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
