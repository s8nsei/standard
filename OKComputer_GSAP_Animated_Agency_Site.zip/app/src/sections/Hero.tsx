import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { useReducedMotion } from '@/hooks/useReducedMotion';

export function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const taglineRef = useRef<HTMLParagraphElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const diamondRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;

    const tagline = taglineRef.current;
    const title = titleRef.current;
    const diamond = diamondRef.current;

    if (!tagline || !title || !diamond) return;

    // Set initial states
    gsap.set(tagline, { y: 40, opacity: 0 });
    gsap.set(title, { y: 80, opacity: 0 });
    gsap.set(diamond, { opacity: 0 });

    // Create entrance timeline
    const tl = gsap.timeline({ delay: 0.3 });

    tl.to(tagline, {
      y: 0,
      opacity: 1,
      duration: 0.6,
      ease: 'expo.out',
    })
      .to(title, {
        y: 0,
        opacity: 1,
        duration: 0.8,
        ease: 'expo.out',
      }, '-=0.3')
      .to(diamond, {
        opacity: 1,
        duration: 0.4,
        ease: 'power2.out',
      }, '-=0.4');

  }, [prefersReducedMotion]);

  const scrollToNext = () => {
    const nextSection = document.getElementById('founding-principle');
    if (nextSection) {
      nextSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className="relative min-h-dvh flex flex-col items-center justify-center bg-standard-bg overflow-hidden"
    >
      {/* Content Container */}
      <div className="text-center px-6 max-w-4xl mx-auto">
        {/* Tagline */}
        <p
          ref={taglineRef}
          className="font-inter text-lg md:text-xl italic font-light text-standard-text/90 mb-8"
          style={{ opacity: prefersReducedMotion ? 1 : undefined }}
        >
          "What is extraordinary elsewhere is ordinary here."
        </p>

        {/* Main Title */}
        <h1
          ref={titleRef}
          className="font-space font-bold text-standard-text tracking-tight"
          style={{
            fontSize: 'clamp(48px, 8vw, 120px)',
            lineHeight: 1,
            letterSpacing: '-0.02em',
            opacity: prefersReducedMotion ? 1 : undefined,
          }}
        >
          THE STANDARD
        </h1>
      </div>

      {/* Scroll Indicator - Diamond */}
      <div
        ref={diamondRef}
        onClick={scrollToNext}
        className="absolute bottom-12 left-1/2 -translate-x-1/2 cursor-pointer transition-transform hover:scale-110"
        style={{ opacity: prefersReducedMotion ? 1 : undefined }}
      >
        <div className="animate-diamond-pulse text-standard-gold text-2xl">
          &#9670;
        </div>
      </div>
    </section>
  );
}
