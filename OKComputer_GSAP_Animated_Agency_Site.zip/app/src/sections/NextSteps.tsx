import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useReducedMotion } from '@/hooks/useReducedMotion';

gsap.registerPlugin(ScrollTrigger);

interface Step {
  number: string;
  title: string;
  description: string;
}

const steps: Step[] = [
  {
    number: '01',
    title: 'THE DISCOVERY CALL',
    description: 'No pitch. Only pattern recognition. We diagnose your current physics and identify which temporal structure matches your velocity. (30 minutes, complimentary)',
  },
  {
    number: '02',
    title: 'THE ARCHITECTURAL PLAN',
    description: 'You receive a detailed proposal—not a quote, but a blueprint showing exactly how the four chambers will function specifically for your business, with explicit fee structure and timeline. (within 48 hours)',
  },
  {
    number: '03',
    title: 'THE CONSTRUCTION',
    description: 'We build simultaneously, not sequentially. Your brand identity emerges while your email flows are written while your ad creative is tested. Everything touches everything. (Project Kickoff)',
  },
  {
    number: '04',
    title: 'THE CALIBRATION',
    description: 'Launch is not the finish line. We monitor, optimize, and adjust for the duration of the engagement, ensuring the physics are working before we declare victory. (Launch & Optimize)',
  },
];

function StepItem({ step, index }: { step: Step; index: number }) {
  const stepRef = useRef<HTMLDivElement>(null);
  const numberRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;

    const stepEl = stepRef.current;
    const numberEl = numberRef.current;
    const contentEl = contentRef.current;

    if (!stepEl || !numberEl || !contentEl) return;

    // Number animation
    gsap.set(numberEl, { y: 80, opacity: 0 });
    gsap.to(numberEl, {
      y: 0,
      opacity: 1,
      duration: 0.8,
      delay: index * 0.15,
      ease: 'expo.out',
      scrollTrigger: {
        trigger: stepEl,
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    });

    // Content animation
    gsap.set(contentEl, { y: 40, opacity: 0 });
    gsap.to(contentEl, {
      y: 0,
      opacity: 1,
      duration: 0.6,
      delay: index * 0.15 + 0.2,
      ease: 'expo.out',
      scrollTrigger: {
        trigger: stepEl,
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => {
        if (st.trigger === stepEl) {
          st.kill();
        }
      });
    };
  }, [prefersReducedMotion, index]);

  return (
    <div
      ref={stepRef}
      className="flex gap-6 md:gap-10 items-start"
      style={{ opacity: prefersReducedMotion ? 1 : undefined }}
    >
      {/* Large Outlined Number */}
      <div
        ref={numberRef}
        className="flex-shrink-0"
        style={{ opacity: prefersReducedMotion ? 1 : undefined }}
      >
        <span
          className="font-space font-bold text-transparent"
          style={{
            fontSize: 'clamp(80px, 12vw, 160px)',
            lineHeight: 0.85,
            WebkitTextStroke: '1px var(--text-secondary)',
          }}
        >
          {step.number}
        </span>
      </div>

      {/* Content */}
      <div
        ref={contentRef}
        className="pt-4 md:pt-8 flex-1"
        style={{ opacity: prefersReducedMotion ? 1 : undefined }}
      >
        <h3 className="font-space font-bold text-standard-text uppercase tracking-widest text-lg md:text-xl mb-3">
          {step.title}
        </h3>
        <p className="body-text text-standard-text/70 text-sm md:text-base max-w-xl">
          {step.description}
        </p>
      </div>
    </div>
  );
}

interface NextStepsProps {
  onRequestPlan: () => void;
  onBookCall: () => void;
}

export function NextSteps({ onRequestPlan, onBookCall }: NextStepsProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;

    const header = headerRef.current;
    const cta = ctaRef.current;

    if (header) {
      gsap.set(header, { y: 80, opacity: 0, rotateX: 8 });
      gsap.to(header, {
        y: 0,
        opacity: 1,
        rotateX: 0,
        duration: 0.8,
        ease: 'expo.out',
        scrollTrigger: {
          trigger: header,
          start: 'top 80%',
          toggleActions: 'play none none none',
        },
      });
    }

    if (cta) {
      gsap.set(cta, { y: 60, opacity: 0 });
      gsap.to(cta, {
        y: 0,
        opacity: 1,
        duration: 0.6,
        delay: 0.3,
        ease: 'expo.out',
        scrollTrigger: {
          trigger: cta,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
      });
    }

    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, [prefersReducedMotion]);

  return (
    <section
      ref={sectionRef}
      id="next-steps"
      className="py-[min(15vh,150px)] px-6 md:px-12 lg:px-20 bg-standard-bg"
    >
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div ref={headerRef} className="mb-16" style={{ opacity: prefersReducedMotion ? 1 : undefined }}>
          <h2
            className="section-header text-standard-text mb-4"
            style={{ fontSize: 'clamp(32px, 4vw, 64px)' }}
          >
            NEXT STEPS
          </h2>
          <p className="subheader text-standard-muted">
            How to Begin The System
          </p>
        </div>

        {/* Steps */}
        <div className="space-y-12 md:space-y-16 mb-20">
          {steps.map((step, index) => (
            <StepItem key={step.number} step={step} index={index} />
          ))}
        </div>

        {/* Final CTA */}
        <div
          ref={ctaRef}
          className="text-center border-t border-standard-muted/20 pt-16"
          style={{ opacity: prefersReducedMotion ? 1 : undefined }}
        >
          <p className="font-inter text-standard-text/90 text-xl md:text-2xl mb-10">
            Ready to elevate your digital presence?
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={onRequestPlan}
              className="btn-primary"
            >
              Request The Architectural Plan
            </button>
            <button
              onClick={onBookCall}
              className="btn-secondary"
            >
              Book Discovery Call
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
