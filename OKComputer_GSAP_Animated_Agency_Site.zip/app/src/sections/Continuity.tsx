import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useReducedMotion } from '@/hooks/useReducedMotion';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

gsap.registerPlugin(ScrollTrigger);

interface ContinuityProtocol {
  id: string;
  name: string;
  price: string;
  quarterlyPrice: string;
  timeline: string;
  bestFor: string;
  description: string;
  features: string[];
  terms: string;
  guarantee: string;
}

const protocols: ContinuityProtocol[] = [
  {
    id: 'preservation',
    name: 'THE PRESERVATION PROTOCOL',
    price: '$2,500',
    quarterlyPrice: '$7,500',
    timeline: '90-Day Cycles, auto-renewing',
    bestFor: 'Alumni of The Foundation, The Momentum, or The Dominance maintaining market position without expansion.',
    description: 'Custodianship of your existing Standard System.',
    features: [
      'Social content execution using established brand templates (3x weekly across primary platforms)',
      'Email automation monitoring and list hygiene maintenance',
      'Monthly performance dashboard (engagement rates, deliverability scores, traffic analysis)',
      'Priority technical support for platform disruptions or architectural failures',
      'Preservation of all brand assets and system configurations as delivered at project completion',
      '90 Days Exclusive Support',
    ],
    terms: 'This agreement constitutes a recurring quarterly maintenance engagement billed in advance at the rate of $7,500 per ninety-day cycle. The minimum commitment is one quarter; renewal occurs automatically unless either party provides written notice of termination thirty days prior to the quarterly renewal date. This protocol is strictly reserved for Clients who have completed The Foundation, The Momentum, or The Dominance within the preceding six months. The Client acknowledges responsibility for maintaining all third-party advertising spend and software subscriptions.',
    guarantee: 'The Standard warrants that all systems under Preservation shall maintain baseline performance metrics established during the final month of the preceding project engagement. Should any chamber degrade in performance by more than fifteen percent due to The Standard negligence, the subsequent quarter shall be discounted by twenty-five percent.',
  },
  {
    id: 'optimization',
    name: 'THE OPTIMIZATION PROTOCOL',
    price: '$4,000',
    quarterlyPrice: '$12,000',
    timeline: '90-Day Cycles, auto-renewing',
    bestFor: 'Alumni seeking compound growth and active system evolution.',
    description: 'Active evolution of your Standard System.',
    features: [
      'Quarterly brand consistency audits ensuring architectural alignment',
      'Full-spectrum social management (daily posting, real-time community engagement, crisis response)',
      'Continuous paid advertising optimization (weekly creative refresh, budget reallocation, A/B testing)',
      'Monthly strategic adjustments to email automation based on behavioral analytics',
      'Dedicated Account Orchestrator with weekly strategy calls and same-business-day response',
      '90 Days Exclusive Support',
    ],
    terms: 'This engagement constitutes a recurring quarterly retainer billed in advance at the rate of $12,000 per ninety-day cycle. The minimum commitment is one quarter; renewal is automatic unless terminated via thirty days written notice prior to the renewal date. The Client must maintain advertising spend levels established during the prior project engagement (minimum $2,500 monthly). Eligibility requires completion of The Foundation, The Momentum, or The Dominance within the preceding twelve months.',
    guarantee: 'The Standard commits to month-over-month performance improvement in prioritized metrics (engagement, cost-per-acquisition, or revenue attribution). Should performance plateau or decline for thirty consecutive days due to Agency strategy, the Agency shall waive the subsequent monthly fee until positive trajectory resumes. All strategic adjustments remain subject to unlimited revision until Client approval.',
  },
];

function ProtocolCard({ protocol, index }: { protocol: ContinuityProtocol; index: number }) {
  const cardRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;

    const card = cardRef.current;
    if (!card) return;

    gsap.set(card, { y: 60, opacity: 0 });

    gsap.to(card, {
      y: 0,
      opacity: 1,
      duration: 0.6,
      delay: index * 0.15,
      ease: 'expo.out',
      scrollTrigger: {
        trigger: card,
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => {
        if (st.trigger === card) {
          st.kill();
        }
      });
    };
  }, [prefersReducedMotion, index]);

  return (
    <div
      ref={cardRef}
      className="standard-card p-8 md:p-10 h-full border-standard-muted/20 hover:border-standard-gold/30 transition-colors duration-500"
      style={{ opacity: prefersReducedMotion ? 1 : undefined }}
    >
      {/* Header */}
      <div className="mb-8">
        <h3 className="font-space font-bold text-standard-text uppercase tracking-widest text-xl mb-4">
          {protocol.name}
        </h3>
        <div className="flex items-baseline gap-3 mb-2">
          <span className="font-space font-bold text-standard-gold text-3xl">
            {protocol.price}
          </span>
          <span className="font-inter text-standard-muted text-sm">
            /month
          </span>
        </div>
        <p className="caption text-standard-muted">
          Quarterly: {protocol.quarterlyPrice} • {protocol.timeline}
        </p>
      </div>

      {/* Best For */}
      <div className="mb-8">
        <p className="text-standard-gold text-xs uppercase tracking-widest mb-2">
          Best For
        </p>
        <p className="body-text text-standard-text/80 text-sm">{protocol.bestFor}</p>
      </div>

      {/* Description */}
      <p className="body-text text-standard-text/70 text-sm mb-8">
        {protocol.description}
      </p>

      {/* Features */}
      <div className="mb-8">
        <ul className="space-y-3">
          {protocol.features.map((feature, idx) => (
            <li
              key={idx}
              className="font-inter text-standard-text/70 text-sm flex items-start gap-2"
            >
              <span className="text-standard-gold text-xs mt-1 flex-shrink-0">&#9670;</span>
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Terms & Guarantee Accordion */}
      <Accordion type="single" collapsible>
        <AccordionItem value="terms" className="border-standard-muted/20">
          <AccordionTrigger className="text-standard-gold text-xs uppercase tracking-widest hover:no-underline">
            View Terms & Guarantee
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4 pt-2">
              <div>
                <p className="text-standard-muted text-xs uppercase tracking-widest mb-2">
                  Terms
                </p>
                <p className="font-inter text-standard-text/60 text-xs leading-relaxed">
                  {protocol.terms}
                </p>
              </div>
              <div>
                <p className="text-standard-muted text-xs uppercase tracking-widest mb-2">
                  Guarantee
                </p>
                <p className="font-inter text-standard-text/60 text-xs leading-relaxed italic">
                  {protocol.guarantee}
                </p>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}

export function Continuity() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const introRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;

    const header = headerRef.current;
    const intro = introRef.current;

    if (header) {
      gsap.set(header, { y: 80, opacity: 0, rotateX: 8 });
      gsap.to(header, {
        y: 0,
        opacity: 1,
        rotateX: 0,
        duration: 0.8,
        ease: 'expo.out',
        scrollTrigger: {
          trigger: header,
          start: 'top 80%',
          toggleActions: 'play none none none',
        },
      });
    }

    if (intro) {
      gsap.set(intro, { y: 60, opacity: 0 });
      gsap.to(intro, {
        y: 0,
        opacity: 1,
        duration: 0.6,
        delay: 0.2,
        ease: 'expo.out',
        scrollTrigger: {
          trigger: intro,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
      });
    }

    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, [prefersReducedMotion]);

  return (
    <section
      ref={sectionRef}
      id="continuity"
      className="py-[min(15vh,150px)] px-6 md:px-12 lg:px-20 bg-standard-bg-dark"
    >
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div ref={headerRef} className="mb-8" style={{ opacity: prefersReducedMotion ? 1 : undefined }}>
          <h2
            className="section-header text-standard-text"
            style={{ fontSize: 'clamp(32px, 4vw, 64px)' }}
          >
            THE CONTINUITY
          </h2>
        </div>

        {/* Intro Text */}
        <div
          ref={introRef}
          className="max-w-3xl mb-12 space-y-6"
          style={{ opacity: prefersReducedMotion ? 1 : undefined }}
        >
          <p className="body-text text-standard-text/90 text-lg">
            A cathedral is not abandoned after the scaffolding comes down. It requires 
            custodianship—the preservation of load-bearing integrity against time, weather, 
            and shifting ground. The Continuity is not a downsizing of engagement; it is 
            the permanent maintenance of the physics we installed.
          </p>
          <p className="body-text text-standard-gold italic">
            These protocols are available exclusively to alumni of The Foundation, The Momentum, 
            or The Dominance. We do not sell continuity to systems we did not architect; we 
            cannot maintain load-bearing walls we did not build.
          </p>
        </div>

        {/* Protocol Cards */}
        <div className="grid md:grid-cols-2 gap-8">
          {protocols.map((protocol, index) => (
            <ProtocolCard key={protocol.id} protocol={protocol} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
