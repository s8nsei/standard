import { useRef, useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useReducedMotion } from '@/hooks/useReducedMotion';
import { Palette, Share2, Target, Mail } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Pillar {
  id: string;
  number: string;
  title: string;
  essence: string;
  services: string[];
  covenant?: string;
  icon: React.ReactNode;
  direction: 'left' | 'right' | 'bottom' | 'top';
}

const pillars: Pillar[] = [
  {
    id: 'branding',
    number: 'I',
    title: 'BRANDING',
    essence: 'Not a logo. Not a color palette. A total experience compressed into a single feeling. Logo systems, color architecture, typography hierarchies, voice and tone guidelines, strategic positioning. Structured, intentional, unforgettable. Your brand, built to last and designed to scale.',
    services: ['Logo Design', 'Color Systems', 'Typography', 'Voice & Tone', 'Brand Strategy', 'Positioning'],
    covenant: 'Unlimited revisions until you are proud to show this to your board, your investors, or your mother. We do not ship work that we would not sign in permanent ink.',
    icon: <Palette size={28} strokeWidth={1.5} />,
    direction: 'left',
  },
  {
    id: 'social',
    number: 'II',
    title: 'SOCIAL MEDIA',
    essence: 'We operate across Youtube, Instagram, TikTok, X and Twitch. Full-service management: schedule, publish, engage, analyze. Your brand voice, amplified and consistent. Community management that builds equity, not just engagement.',
    services: ['Platform Strategy', 'Content Calendar', 'Daily Posting', 'Community Engagement', 'Performance Analytics'],
    icon: <Share2 size={28} strokeWidth={1.5} />,
    direction: 'right',
  },
  {
    id: 'paid',
    number: 'III',
    title: 'PAID ADVERTISING',
    essence: 'Meta, Google, TikTok—managed as a unified front, not siloed channels. Campaigns managed with algorithmic precision. Our systems adjust budgets autonomously, minute by minute. A/B test, optimize, scale and ensure brand integrity never sacrifices itself to efficiency.',
    services: ['Meta Ads', 'Google Ads', 'TikTok Ads', 'Budget Optimization', 'A/B Testing'],
    covenant: 'If we do not hit the agreed KPIs by day 30 of engagement, month two is entirely free. We succeed before we charge premium rates.',
    icon: <Target size={28} strokeWidth={1.5} />,
    direction: 'bottom',
  },
  {
    id: 'email',
    number: 'IV',
    title: 'EMAIL MARKETING',
    essence: 'We observe behavioral patterns—mouse movement, temporal psychology, engagement gravity. Welcome sequences that convert strangers to advocates. Abandoned cart recovery that respects the customer. Post-purchase nurturing that increases lifetime value.',
    services: ['Platform Setup', 'Automation Flows', 'Campaign Design', 'List Segmentation', 'Performance Tracking'],
    icon: <Mail size={28} strokeWidth={1.5} />,
    direction: 'top',
  },
];

function PillarPanel({
  pillar,
  isExpanded,
  onHover,
  onLeave,
}: {
  pillar: Pillar;
  isExpanded: boolean;
  onHover: () => void;
  onLeave: () => void;
}) {
  const panelRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;

    const panel = panelRef.current;
    if (!panel) return;

    const directionMap = {
      left: { x: -100, y: 0 },
      right: { x: 100, y: 0 },
      bottom: { x: 0, y: 100 },
      top: { x: 0, y: -100 },
    };

    const { x, y } = directionMap[pillar.direction];

    gsap.set(panel, { x, y, opacity: 0 });

    gsap.to(panel, {
      x: 0,
      y: 0,
      opacity: 1,
      duration: 0.8,
      ease: 'expo.out',
      scrollTrigger: {
        trigger: panel,
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => {
        if (st.trigger === panel) {
          st.kill();
        }
      });
    };
  }, [prefersReducedMotion, pillar.direction]);

  return (
    <div
      ref={panelRef}
      className={`relative border border-standard-muted/20 bg-standard-bg/80 backdrop-blur-sm overflow-hidden cursor-pointer transition-all duration-600 ease-out ${
        isExpanded ? 'flex-[2]' : 'flex-1'
      }`}
      style={{
        opacity: prefersReducedMotion ? 1 : undefined,
        minHeight: '500px',
      }}
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
    >
      <div className="p-6 md:p-8 h-full flex flex-col">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <div className="text-standard-gold">{pillar.icon}</div>
          <div>
            <span className="text-standard-muted text-sm font-space">{pillar.number}</span>
            <h4 className="font-space font-bold text-standard-text uppercase tracking-widest">
              {pillar.title}
            </h4>
          </div>
        </div>

        {/* Content - always visible but expanded shows more */}
        <div className="flex-1">
          <p className={`body-text text-standard-text/80 mb-6 transition-all duration-500 ${
            isExpanded ? 'line-clamp-none' : 'line-clamp-3'
          }`}>
            {pillar.essence}
          </p>

          {/* Services - always visible */}
          <div className="mb-6">
            <ul className="space-y-2">
              {pillar.services.map((service, index) => (
                <li
                  key={index}
                  className="font-inter text-standard-text/70 text-sm flex items-center gap-2"
                >
                  <span className="text-standard-gold text-xs">&#9670;</span>
                  {service}
                </li>
              ))}
            </ul>
          </div>

          {/* Covenant - expanded only */}
          {pillar.covenant && (
            <div
              className={`transition-all duration-500 overflow-hidden ${
                isExpanded ? 'opacity-100 max-h-96' : 'opacity-0 max-h-0'
              }`}
            >
              <div className="border-t border-standard-gold/30 pt-4 mt-4">
                <p className="text-standard-gold text-xs uppercase tracking-widest mb-2">
                  The Covenant
                </p>
                <p className="font-inter text-standard-text/70 text-sm italic">
                  {pillar.covenant}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function FourPillars() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const metaphorRef = useRef<HTMLDivElement>(null);
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;

    const header = headerRef.current;
    const metaphor = metaphorRef.current;

    if (header) {
      gsap.set(header, { y: 80, opacity: 0, rotateX: 8 });
      gsap.to(header, {
        y: 0,
        opacity: 1,
        rotateX: 0,
        duration: 0.8,
        ease: 'expo.out',
        scrollTrigger: {
          trigger: header,
          start: 'top 80%',
          toggleActions: 'play none none none',
        },
      });
    }

    if (metaphor) {
      gsap.set(metaphor, { y: 60, opacity: 0 });
      gsap.to(metaphor, {
        y: 0,
        opacity: 1,
        duration: 0.6,
        delay: 0.2,
        ease: 'expo.out',
        scrollTrigger: {
          trigger: metaphor,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
      });
    }

    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, [prefersReducedMotion]);

  return (
    <section
      ref={sectionRef}
      id="four-pillars"
      className="py-[min(15vh,150px)] px-6 md:px-12 lg:px-20 bg-standard-bg"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div ref={headerRef} className="mb-12" style={{ opacity: prefersReducedMotion ? 1 : undefined }}>
          <h2
            className="section-header text-standard-text mb-4"
            style={{ fontSize: 'clamp(32px, 4vw, 64px)' }}
          >
            FOUR PILLARS. ONE SYSTEM.
          </h2>
        </div>

        {/* Cathedral Metaphor */}
        <div
          ref={metaphorRef}
          className="max-w-3xl mb-16 space-y-6"
          style={{ opacity: prefersReducedMotion ? 1 : undefined }}
        >
          <p className="body-text text-standard-text/90 text-lg">
            A cathedral is not a collection of separate crafts. The stained glass, the flying 
            buttress, the foundation stone—each exists only in relation to the others. Remove 
            one, and the system collapses.
          </p>
          <p className="body-text text-standard-text/90">
            The Standard does not offer services. We install an operating system.
          </p>
          <p className="body-text text-standard-text/80">
            Branding. Social. Paid Acquisition. Email. These are not adjacent offerings. They 
            are four pillars of the same heart, circulating a single pulse: momentum. Identity 
            generates attraction. Attraction generates traffic. Traffic generates relationships. 
            Relationships generate revenue.
          </p>
          <p className="body-text text-standard-text/70 italic">
            This is The Standard System. Invisible infrastructure. Visible results.
          </p>
        </div>

        {/* Four Pillars Panels - Desktop */}
        <div className="hidden lg:flex gap-4">
          {pillars.map((pillar, index) => (
            <PillarPanel
              key={pillar.id}
              pillar={pillar}
              isExpanded={expandedIndex === index}
              onHover={() => setExpandedIndex(index)}
              onLeave={() => setExpandedIndex(null)}
            />
          ))}
        </div>

        {/* Four Pillars - Mobile/Tablet (Stacked) */}
        <div className="lg:hidden space-y-6">
          {pillars.map((pillar) => (
            <div
              key={pillar.id}
              className="border border-standard-muted/20 bg-standard-bg/80 p-6"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="text-standard-gold">{pillar.icon}</div>
                <div>
                  <span className="text-standard-muted text-sm font-space">{pillar.number}</span>
                  <h4 className="font-space font-bold text-standard-text uppercase tracking-widest">
                    {pillar.title}
                  </h4>
                </div>
              </div>
              <p className="body-text text-standard-text/80 mb-4">{pillar.essence}</p>
              <ul className="space-y-2 mb-4">
                {pillar.services.map((service, idx) => (
                  <li
                    key={idx}
                    className="font-inter text-standard-text/70 text-sm flex items-center gap-2"
                  >
                    <span className="text-standard-gold text-xs">&#9670;</span>
                    {service}
                  </li>
                ))}
              </ul>
              {pillar.covenant && (
                <div className="border-t border-standard-gold/30 pt-4 mt-4">
                  <p className="text-standard-gold text-xs uppercase tracking-widest mb-2">
                    The Covenant
                  </p>
                  <p className="font-inter text-standard-text/70 text-sm italic">
                    {pillar.covenant}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
