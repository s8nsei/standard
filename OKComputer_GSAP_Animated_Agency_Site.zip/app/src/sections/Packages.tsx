import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useReducedMotion } from '@/hooks/useReducedMotion';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

gsap.registerPlugin(ScrollTrigger);

interface Package {
  id: string;
  name: string;
  price: string;
  standardPrice: string;
  timeline: string;
  bestFor: string;
  description: string;
  features: string[];
  terms: string;
  guarantee: string;
  cta: string;
}

const packages: Package[] = [
  {
    id: 'foundation',
    name: 'THE FOUNDATION',
    price: '$4,500',
    standardPrice: '$7,500',
    timeline: '30 Days',
    bestFor: 'Startups, Personal Brands, New Ventures entering the market with intention.',
    description: 'Complete system build for new ventures. No monthly fees. No ongoing obligation.',
    features: [
      'Complete Brand Identity System (logo, color architecture, typography, voice guidelines)',
      'All source files with ownership transferred upon final payment',
      'Social Media Platform Architecture (optimized bios, 30 days of scheduled content)',
      'Paid Advertising Pilot (campaign structure, 2 creative variants, targeting parameters)',
      'Ad Spend: We gift $1,000 in Meta credits; advise total budget of $2,500',
      'Email Capture Mechanism (1 lead magnet PDF, automated welcome sequence, list segmentation)',
      '30 Days Support',
    ],
    terms: 'This engagement constitutes a fixed-scope project with a defined duration of 30 days from formal kickoff to final handoff. The Client shall remit fifty percent of the total fee ($2,250) as a deposit to initiate work, with the remaining fifty percent ($2,250) due upon delivery of final brand identity files. This is a finite engagement with no recurring monthly obligation. The Standard shall apply $1,000 in platform advertising credits as a gift toward the Client\'s campaign; however, the Client acknowledges responsibility for funding an additional $1,500 in ad spend. Any work requested beyond the defined scope shall be billed at a rate of $175 per hour.',
    guarantee: 'The Standard commits to unlimited revision cycles on all brand assets until the Client determines the work is suitable for presentation to its board of directors or stakeholders.',
    cta: 'Begin The Foundation',
  },
  {
    id: 'momentum',
    name: 'THE MOMENTUM',
    price: '$9,000',
    standardPrice: '$15,000',
    timeline: '90-Day Cycles',
    bestFor: 'Growing companies ready to scale their market presence.',
    description: 'Everything in Foundation, plus comprehensive scaling systems.',
    features: [
      'Complete system build (if not existing from previous tier)',
      '90 Days of daily social media operation (content calendar, publishing, community management)',
      '3 conversion-optimized landing pages (A/B tested)',
      'Paid Acquisition Scale (daily optimization, weekly creative refreshes)',
      'Ad Spend: We gift $2,000 total ($667/month); advise total budget of $5,000',
      'Email Automation Ecosystem (3 behavioral flows: abandoned cart, post-purchase, win-back)',
      'Monthly analytics reviews with strategic pivot recommendations',
      'Final playbook documentation for system continuity',
      '90 Days Support & Optimization',
    ],
    terms: 'This engagement constitutes a 90-Day Strategic Partnership billed quarterly in advance with defined termination on day ninety unless both parties execute a written renewal. The Standard shall apply $2,000 in advertising credits as a gift across the ninety days terms; the Client acknowledges obligation to fund an additional $3,000 in media spend. No pro-rata refunds or mid-quarter cancellations are permitted; the Client may exit only upon completion of the ninety-day term.',
    guarantee: 'The Standard hereby covenants that if mutually agreed key performance indicators—whether click-through rate, cost per acquisition, or revenue targets—are not achieved by day 30 of the engagement, Month Two fees shall be waived in their entirety until such KPIs are met. The Standard further guarantees unlimited revisions upon all creative and brand assets until the Client deems them board-ready.',
    cta: 'Begin The Momentum',
  },
  {
    id: 'dominance',
    name: 'THE DOMINANCE',
    price: '$18,000',
    standardPrice: '$28,000',
    timeline: '180-Day Cycles',
    bestFor: 'Established businesses demanding market leadership.',
    description: 'Everything in Momentum, plus unlimited applications and dedicated support.',
    features: [
      'Unlimited Brand Applications (packaging, presentations, motion graphics templates)',
      '180 Days full-spectrum social management (daily posting, video production, influencer coordination)',
      'Advanced Paid Strategies (retargeting architectures, seasonal campaign builds, lookalike scaling)',
      'Ad Spend: We gift $5,000 total ($833/month); advise total budget of $20,000',
      '4 SEO-cornerstone content pieces (interlinked with email funnels)',
      'Complete customer journey mapping and optimization',
      'Dedicated Account Orchestrator with weekly strategy calls',
      'Quarterly business intelligence reports with competitive analysis',
      '180 Days Exclusive Support',
    ],
    terms: 'This engagement constitutes an ongoing quarterly retainer with initial 180-day commitment requiring full commitment through the six-month duration. The Client shall remit $9,000 at commencement to cover Months One through Three, and a second payment of $8,000 at the start of Month Four. The Standard shall apply $5,000 in advertising credits as a gift; the Client accepts responsibility for funding an additional $15,000 in media spend. Should the Client seek early termination, written notice of thirty days is required.',
    guarantee: 'The Agency warrants that if agreed performance indicators are not satisfied within the first ninety days, the invoice for next quarter shall be reduced by twenty-five percent. The Standard guarantees unlimited revision cycles upon all creative deliverables until final approval is granted.',
    cta: 'Begin The Dominance',
  },
  {
    id: 'enterprise',
    name: 'THE ENTERPRISE',
    price: 'Custom',
    standardPrice: 'Starting at $35K/quarter',
    timeline: '180-Day Cycles',
    bestFor: 'Corporations and rapid-scale operations.',
    description: 'Fully customized engagement for enterprise-level needs.',
    features: [
      'Brand Evolution Strategy (quarterly repositioning, competitive intelligence, market analysis)',
      'In-house Content Studio access (weekly photo/video shoots, editing, post-production)',
      'Ad Spend: We gift $10,000 in quarterly credits; advise total budget of $60,000 per quarter',
      'White-glove analytics reporting (real-time dashboards, executive summaries)',
      'Dedicated Architect + Executor team (Slack integration, same-day SLA response)',
      'Quarterly strategy summits and priority crisis management',
      '180 Days Exclusive Support',
    ],
    terms: 'This engagement constitutes an ongoing quarterly retainer with initial 180-day commitment requiring full dedication through the six-month duration, billed quarterly in advance. The Client shall remit $35,000 at commencement to cover Months One through Three, and a second payment of $35,000 at the start of Month Four, for a total six-month investment of $70,000. The Standard shall apply $20,000 in advertising credits as a gift; the Client accepts responsibility for funding an additional $100,000 in media spend. Should the Client seek early termination prior to completion of the six-month term, written notice of thirty days is required.',
    guarantee: 'The Standard covenants that if agreed return-on-ad-spend targets or acquisition metrics are not achieved by day ninety of any given quarter, the invoice for next quarter shall be reduced by twenty-five percent. The Standard guarantees unlimited revision cycles upon all creative deliverables until final approval is granted.',
    cta: 'Begin The Enterprise',
  },
];

function PackageCard({
  pkg,
  index,
  onSelect,
}: {
  pkg: Package;
  index: number;
  onSelect: (pkg: Package) => void;
}) {
  const cardRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;

    const card = cardRef.current;
    if (!card) return;

    gsap.set(card, { scale: 0.95, opacity: 0 });

    gsap.to(card, {
      scale: 1,
      opacity: 1,
      duration: 0.6,
      delay: index * 0.1,
      ease: 'expo.out',
      scrollTrigger: {
        trigger: card,
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => {
        if (st.trigger === card) {
          st.kill();
        }
      });
    };
  }, [prefersReducedMotion, index]);

  return (
    <div
      ref={cardRef}
      className="standard-card p-6 md:p-8 flex flex-col h-full"
      style={{ opacity: prefersReducedMotion ? 1 : undefined }}
    >
      {/* Header */}
      <div className="mb-6">
        <h3 className="font-space font-bold text-standard-text uppercase tracking-widest text-xl mb-4">
          {pkg.name}
        </h3>
        <div className="flex items-baseline gap-3 mb-2">
          <span className="font-space font-bold text-standard-gold text-3xl">
            {pkg.price}
          </span>
          <span className="font-inter text-standard-muted text-sm line-through">
            {pkg.standardPrice}
          </span>
        </div>
        <p className="caption text-standard-muted uppercase">
          Timeline: {pkg.timeline}
        </p>
      </div>

      {/* Best For */}
      <div className="mb-6">
        <p className="text-standard-gold text-xs uppercase tracking-widest mb-2">
          Best For
        </p>
        <p className="body-text text-standard-text/80 text-sm">{pkg.bestFor}</p>
      </div>

      {/* Features */}
      <div className="flex-1 mb-6">
        <ul className="space-y-3">
          {pkg.features.map((feature, idx) => (
            <li
              key={idx}
              className="font-inter text-standard-text/70 text-sm flex items-start gap-2"
            >
              <span className="text-standard-gold text-xs mt-1 flex-shrink-0">&#9670;</span>
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Terms & Guarantee Accordion */}
      <Accordion type="single" collapsible className="mb-6">
        <AccordionItem value="terms" className="border-standard-muted/20">
          <AccordionTrigger className="text-standard-gold text-xs uppercase tracking-widest hover:no-underline">
            View Terms & Guarantee
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4 pt-2">
              <div>
                <p className="text-standard-muted text-xs uppercase tracking-widest mb-2">
                  Terms
                </p>
                <p className="font-inter text-standard-text/60 text-xs leading-relaxed">
                  {pkg.terms}
                </p>
              </div>
              <div>
                <p className="text-standard-muted text-xs uppercase tracking-widest mb-2">
                  Guarantee
                </p>
                <p className="font-inter text-standard-text/60 text-xs leading-relaxed italic">
                  {pkg.guarantee}
                </p>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      {/* CTA Button */}
      <button
        onClick={() => onSelect(pkg)}
        className="btn-primary w-full text-center"
      >
        {pkg.cta}
      </button>
    </div>
  );
}

interface PackagesProps {
  onPackageSelect: (pkg: Package) => void;
}

export function Packages({ onPackageSelect }: PackagesProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;

    const header = headerRef.current;
    if (!header) return;

    gsap.set(header, { y: 80, opacity: 0, rotateX: 8 });
    gsap.to(header, {
      y: 0,
      opacity: 1,
      rotateX: 0,
      duration: 0.8,
      ease: 'expo.out',
      scrollTrigger: {
        trigger: header,
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, [prefersReducedMotion]);

  return (
    <section
      ref={sectionRef}
      id="packages"
      className="py-[min(15vh,150px)] px-6 md:px-12 lg:px-20 bg-standard-bg"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div ref={headerRef} className="mb-16" style={{ opacity: prefersReducedMotion ? 1 : undefined }}>
          <h2
            className="section-header text-standard-text"
            style={{ fontSize: 'clamp(32px, 4vw, 64px)' }}
          >
            CHOOSE YOUR LEVEL OF TRANSFORMATION
          </h2>
        </div>

        {/* Package Cards Grid */}
        <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-6">
          {packages.map((pkg, index) => (
            <PackageCard
              key={pkg.id}
              pkg={pkg}
              index={index}
              onSelect={onPackageSelect}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

export type { Package };
