import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useReducedMotion } from '@/hooks/useReducedMotion';
import { Cpu, Compass, Hammer, Eye } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface EntityCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  delay: number;
}

function EntityCard({ icon, title, description, delay }: EntityCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;

    const card = cardRef.current;
    if (!card) return;

    gsap.set(card, { y: 60, opacity: 0 });

    gsap.to(card, {
      y: 0,
      opacity: 1,
      duration: 0.6,
      delay,
      ease: 'expo.out',
      scrollTrigger: {
        trigger: card,
        start: 'top 85%',
        toggleActions: 'play none none none',
      },
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => {
        if (st.trigger === card) {
          st.kill();
        }
      });
    };
  }, [prefersReducedMotion, delay]);

  return (
    <div
      ref={cardRef}
      className="p-8 border border-standard-muted/20 bg-standard-bg/50"
      style={{ opacity: prefersReducedMotion ? 1 : undefined }}
    >
      <div className="text-standard-gold mb-6">
        {icon}
      </div>
      <h4 className="font-space font-bold text-standard-text text-lg uppercase tracking-widest mb-4">
        {title}
      </h4>
      <p className="font-inter text-standard-text/80 text-sm leading-relaxed">
        {description}
      </p>
    </div>
  );
}

export function FoundingPrinciple() {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLHeadingElement>(null);
  const bodyRefs = useRef<HTMLParagraphElement[]>([]);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;

    const header = headerRef.current;
    const bodyParagraphs = bodyRefs.current.filter(Boolean);

    if (!header) return;

    // Header animation
    gsap.set(header, { y: 80, opacity: 0, rotateX: 8 });
    gsap.to(header, {
      y: 0,
      opacity: 1,
      rotateX: 0,
      duration: 0.8,
      ease: 'expo.out',
      scrollTrigger: {
        trigger: header,
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    });

    // Body paragraphs animation
    bodyParagraphs.forEach((p, index) => {
      gsap.set(p, { y: 60, opacity: 0 });
      gsap.to(p, {
        y: 0,
        opacity: 1,
        duration: 0.6,
        delay: index * 0.15,
        ease: 'expo.out',
        scrollTrigger: {
          trigger: p,
          start: 'top 85%',
          toggleActions: 'play none none none',
        },
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, [prefersReducedMotion]);

  const addToBodyRefs = (el: HTMLParagraphElement | null, index: number) => {
    if (el) bodyRefs.current[index] = el;
  };

  return (
    <section
      ref={sectionRef}
      id="founding-principle"
      className="py-[min(15vh,150px)] px-6 md:px-12 lg:px-20 bg-standard-bg"
    >
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <h2
          ref={headerRef}
          className="section-header text-standard-text mb-16"
          style={{
            fontSize: 'clamp(32px, 4vw, 64px)',
            opacity: prefersReducedMotion ? 1 : undefined,
          }}
        >
          THE FOUNDING PRINCIPLE
        </h2>

        {/* Content Grid */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Left Column - Body Text */}
          <div className="space-y-6">
            <p
              ref={el => addToBodyRefs(el, 0)}
              className="body-text text-standard-text/90 text-lg"
              style={{ opacity: prefersReducedMotion ? 1 : undefined }}
            >
              Based in Los Angeles, we operate at the intersection of entertainment capital 
              ambition and Silicon Valley precision. We have observed that the modern user is 
              sophisticated, distracted, and ruthless with their attention. They do not forgive 
              mediocrity. They do not tolerate friction. They expect the impossible delivered 
              with grace.
            </p>
            <p
              ref={el => addToBodyRefs(el, 1)}
              className="body-text text-standard-text/90"
              style={{ opacity: prefersReducedMotion ? 1 : undefined }}
            >
              This document is our creed. These words are our covenant. What follows is not 
              policy—it is identity.
            </p>
          </div>

          {/* Right Column - Core Principles */}
          <div className="space-y-10">
            {/* The Silence */}
            <div>
              <h3
                ref={el => addToBodyRefs(el, 2)}
                className="subheader text-standard-gold mb-4"
                style={{ opacity: prefersReducedMotion ? 1 : undefined }}
              >
                I. THE SILENCE
              </h3>
              <p
                ref={el => addToBodyRefs(el, 3)}
                className="body-text text-standard-text/80"
                style={{ opacity: prefersReducedMotion ? 1 : undefined }}
              >
                Digital negative space is not emptiness—it is intention. The site does not 
                scream; it waits. It invites. It respects the intelligence of its visitors. 
                No superfluous elements. No decorative noise.
              </p>
              <p
                ref={el => addToBodyRefs(el, 4)}
                className="body-text text-standard-text/60 italic mt-4 text-sm"
                style={{ opacity: prefersReducedMotion ? 1 : undefined }}
              >
                "Silence is not the absence of sound. It is the presence of purpose."
              </p>
            </div>

            {/* The Structure */}
            <div>
              <h3
                ref={el => addToBodyRefs(el, 5)}
                className="subheader text-standard-gold mb-4"
                style={{ opacity: prefersReducedMotion ? 1 : undefined }}
              >
                II. THE STRUCTURE
              </h3>
              <p
                ref={el => addToBodyRefs(el, 6)}
                className="body-text text-standard-text/80"
                style={{ opacity: prefersReducedMotion ? 1 : undefined }}
              >
                Our work draws from the verticality and materiality of Los Angeles itself—raw 
                stone mixed with algorithms, textures you can feel through the screen. Motion 
                is physics, not animation. Every transition obeys the laws of momentum and inertia. 
                The structure breathes, adapts, and evolves, yet remains fundamentally sound.
              </p>
            </div>
          </div>
        </div>

        {/* The Four Entities */}
        <div className="mt-20">
          <h3
            ref={el => addToBodyRefs(el, 7)}
            className="subheader text-standard-gold mb-8"
            style={{ opacity: prefersReducedMotion ? 1 : undefined }}
          >
            III. THE FOUR ENTITIES
          </h3>
          <p
            ref={el => addToBodyRefs(el, 8)}
            className="body-text text-standard-text/80 mb-12 max-w-3xl"
            style={{ opacity: prefersReducedMotion ? 1 : undefined }}
          >
            We operate as a single consciousness distributed across four distinct entities. 
            Each possesses unique capabilities. Together, they form an operational whole greater 
            than the sum of its parts:
          </p>

          {/* Entity Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <EntityCard
              icon={<Cpu size={32} strokeWidth={1.5} />}
              title="THE ORCHESTRATOR"
              description="Our silent colleague, master of pattern recognition, tireless in analysis. We do not treat artificial intelligence as a tool; we treat it as a teammate—acknowledged, respected, integrated."
              delay={0}
            />
            <EntityCard
              icon={<Compass size={32} strokeWidth={1.5} />}
              title="THE ARCHITECT"
              description="Sees the entire structure before a single line is written. Designs for seismic forces—both geological and market-based. Understands that true architecture anticipates stresses before they manifest."
              delay={0.1}
            />
            <EntityCard
              icon={<Hammer size={32} strokeWidth={1.5} />}
              title="THE EXECUTOR"
              description="Transforms architectural vision into operational reality. Where The Architect dreams, The Executor builds. Precision in execution honors the intent of design."
              delay={0.2}
            />
            <EntityCard
              icon={<Eye size={32} strokeWidth={1.5} />}
              title="THE CLIENT"
              description="The vision-bearer, the constraint-definer, the success-measurer. Without The Client, the structure has no purpose."
              delay={0.3}
            />
          </div>
        </div>
      </div>
    </section>
  );
}
